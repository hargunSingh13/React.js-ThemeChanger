import React, { useState } from 'react'

const Theme = () => {
    const [click, setClick] = useState(true);
    const [color, setColor] = useState();
    const change = () => {
        setClick(click ? false : true);
    }
    const red = () =>{
        setColor("red");
    }
    const pink = () =>{
        setColor("pink");
    }
    const blue = () =>{
        setColor('blue');
    }
    const yellow = () =>{
        setColor("yellow");
    }
    const orange = () =>{
        setColor("orange");
    }


    return (
        <>
            <div className={click ?  'flex' : 'bg flex'}>
                <div className='w-3/12 ml-5 '>
                <div className={color === "red" ? "card bg-base-100 w-60 ml-5 mt-5 shadow-xl red " :
                     color == "blue" ? "card bg-base-100 w-60 ml-5 mt-5 shadow-xl blue" : color == "pink" ? "card bg-base-100 w-60 ml-5 mt-5 shadow-xl pink " : color == "yellow" ? "card bg-base-100 w-60 ml-5 mt-5 shadow-xl yellow" : color == "orange" ? "card bg-base-100 w-60 ml-5 mt-5 shadow-xl orange" :"card bg-base-100 w-60 ml-5 mt-5 shadow-xl "}>
                  <figure>
                    <img
                      src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.webp"
                      alt="Shoes" />
                  </figure>
                  <div className="card-body">
                    <h2 className="card-title">
                      Shoes!
                      <div className="badge badge-secondary">NEW</div>
                    </h2>
                    <p>If a dog chews shoes whose shoes does he choose?</p>
                    <div className="card-actions justify-end">
                      <div className="badge badge-outline">Fashion</div>
                      <div className="badge badge-outline">Products</div>
                    </div>
                  </div>
                </div>

                <div className={color === "red" ? "card card-side w-60 ml-5 mt-5 bg-base-100 shadow-xl red" :
                     color == "blue" ? "card card-side w-60 ml-5 mt-5 bg-base-100 shadow-xl blue" : color == "pink" ? "card card-side w-60 ml-5 mt-5 bg-base-100 shadow-xl  pink " : color == "yellow" ? "card card-side w-60 ml-5 mt-5 bg-base-100 shadow-xl  yellow" : color == "orange" ? "card card-side w-60 ml-5 mt-5 bg-base-100 shadow-xl  orange": "card card-side w-60 ml-5 mt-5 bg-base-100 shadow-xl "}>
                  <figure>
                    <img
                      src="https://img.daisyui.com/images/stock/photo-1635805737707-575885ab0820.webp"
                      alt="Movie" />
                  </figure>
                  <div className="card-body">
                    <h2 className="card-title">New movie is released!</h2>
                    <p>Click the button to watch on Jetflix app.</p>
                    <div className="card-actions justify-end">
                      <button className="btn btn-primary">Watch</button>
                    </div>
                  </div>
                </div>

                <div className="card lg:card-side bg-base-100 w-60 ml-5 mt-5 shadow-xl">
                  <figure>
                    <img
                      src="https://img.daisyui.com/images/stock/photo-1494232410401-ad00d5433cfa.webp"
                      alt="Album" />
                  </figure>
                  <div className="card-body">
                    <h2 className="card-title">New album is released!</h2>
                    <p>Click the button to listen on Spotiwhy app.</p>
                    <div className="card-actions justify-end">
                      <button className="btn btn-primary">Listen</button>
                    </div>
                  </div>
                </div>
                </div>
                <div className='w-6/12'>
                    <h2 className={color === "red" ? " text-3xl font-bold text-center mb-5 text-red-400 mt-5" :
                     color == "blue" ? " text-3xl font-bold text-center mb-5 text-blue-300 mt-5" : color == "pink" ? " text-3xl font-bold text-center mb-5 text-pink-300 mt-5" : color == "yellow" ? " text-3xl font-bold text-center mb-5 text-yellow-300 mt-5" : color == "orange" ? " text-3xl font-bold text-center mb-5 text-orange-300 mt-5" : click  ? 'text-3xl font-bold text-center mb-5 text-green-300 mt-5' : 'text-3xl font-bold text-center mb-5 text-white mt-5' }>Theme Change Form</h2>
                    

                    <input className={color === "red" ? "red w-full h-10 p-4  mb-5 mt-5" :
                     color == "blue" ? "blue w-full h-10 p-4  mb-5 mt-5 " : color == "pink" ? "pink w-full h-10 p-4  mb-5 mt-5" : color == "yellow" ? "yellow w-full h-10 p-4  mb-5 mt-5" : color == "orange" ? "orange w-full h-10 p-4  mb-5 mt-5" : click  ? "light w-full h-10 p-4  mb-5 mt-5 " : "dark w-full h-10 p-4  mb-5 mt-5"} placeholder='Enter Your Name'></input><br />
                     
                    <input className={color === "red" ? "red w-full h-10 p-4  mb-5 " :
                     color == "blue" ? "blue w-full h-10 p-4  mb-5  " : color == "pink" ? "pink w-full h-10 p-4  mb-5 " : color == "yellow" ? "yellow w-full h-10 p-4  mb-5 " : color == "orange" ? "orange w-full h-10 p-4  mb-5 " : click  ? "light w-full h-10 p-4  mb-5 " : "dark w-full h-10 p-4  mb-5 "} type='number' placeholder='Enter Your Age'></input><br />
                      
                    <input className={color === "red" ? "red w-full h-10 p-4  mb-5 " :
                     color == "blue" ? "blue w-full h-10 p-4  mb-5  " : color == "pink" ? "pink w-full h-10 p-4  mb-5 " : color == "yellow" ? "yellow w-full h-10 p-4  mb-5 " : color == "orange" ? "orange w-full h-10 p-4  mb-5 " : click  ? "light w-full h-10 p-4  mb-5 " : "dark w-full h-10 p-4  mb-5 "} type='email' placeholder='Enter Your Email'></input><br />

                    <div className='flex'>
                        <div className='w-4/12 mr-5'>
                            <input className={color === "red" ? "red w-full h-10 p-4  mb-5 " :
                     color == "blue" ? "blue w-full h-10 p-4  mb-5  " : color == "pink" ? "pink w-full h-10 p-4  mb-5 " : color == "yellow" ? "yellow w-full h-10 p-4  mb-5 " : color == "orange" ? "orange w-full h-10 p-4  mb-5 " : click  ? "light w-full h-10 p-4  mb-5 " : "dark w-full h-10 p-4  mb-5 "} type='date' />
                        </div>
                        <div className='w-8/12'>
                            <input className={color === "red" ? "red w-full h-10 p-4  mb-5 " :
                     color == "blue" ? "blue w-full h-10 p-4  mb-5  " : color == "pink" ? "pink w-full h-10 p-4  mb-5 " : color == "yellow" ? "yellow w-full h-10 p-4  mb-5 " : color == "orange" ? "orange w-full h-10 p-4  mb-5 " : click  ? "light w-full h-10 p-4  mb-5 " : "dark w-full h-10 p-4  mb-5 "} type='email' placeholder='Enter Your Email'></input>
                        </div>
                    </div>
                    <input className={color === "red" ? "red w-full h-10 p-4  mb-5 " :
                     color == "blue" ? "blue w-full h-10 p-4  mb-5  " : color == "pink" ? "pink w-full h-10 p-4  mb-5 " : color == "yellow" ? "yellow w-full h-10 p-4  mb-5 " : color == "orange" ? "orange w-full h-10 p-4  mb-5 " : click  ? "light w-full h-10 p-4  mb-5 " : "dark w-full h-10 p-4  mb-5 "}type='password' placeholder='Enter Password'></input><br />

                    <input className={color === "red" ? "red w-full h-10 p-4  mb-5 " :
                     color == "blue" ? "blue w-full h-10 p-4  mb-5  " : color == "pink" ? "pink w-full h-10 p-4  mb-5 " : color == "yellow" ? "yellow w-full h-10 p-4  mb-5 " : color == "orange" ? "orange w-full h-10 p-4  mb-5 " : click  ? "light w-full h-10 p-4  mb-5 " : "dark w-full h-10 p-4  mb-5 "} type='password' placeholder='Confirm Password'></input><br />

                    <button className={color === "red" ? "btn mb-5 bg-red-500 " :
                     color == "blue" ? "btn mb-5 bg-blue-400  " : color == "pink" ? "btn mb-5 bg-pink-400 " : color == "yellow" ? "btn mb-5 bg-yellow-400" : color == "orange" ? "btn mb-5 bg-orange-400 " : click ? 'btn mb-5 bg-green-400 ' : 'btn mb-5 bg-white '}>Submit</button>
                    <div className="overflow-x-auto">
                        <table className="table">
                            {/* head */}
                            <thead>
                                <tr>
                                    <th>
                                        <label>
                                            <input type="checkbox" className="checkbox" />
                                        </label>
                                    </th>
                                    <th>Name</th>
                                    <th>Job</th>
                                    <th>Favorite Color</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {/* row 1 */}
                                <tr>
                                    <th>
                                        <label>
                                            <input type="checkbox" className="checkbox" />
                                        </label>
                                    </th>
                                    <td>
                                        <div className="flex items-center gap-3">
                                            <div className="avatar">
                                                <div className="mask mask-squircle h-12 w-12">
                                                    <img
                                                        src="https://img.daisyui.com/images/profile/demo/2@94.webp"
                                                        alt="Avatar Tailwind CSS Component" />
                                                </div>
                                            </div>
                                            <div>
                                                <div className="font-bold">Hart Hagerty</div>
                                                <div className="text-sm opacity-50">United States</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        Zemlak, Daniel and Leannon
                                        <br />
                                        <span className="badge badge-ghost badge-sm">Desktop Support Technician</span>
                                    </td>
                                    <td>Purple</td>
                                    <th>
                                        <button className="btn btn-ghost btn-xs">details</button>
                                    </th>
                                </tr>
                                {/* row 2 */}
                                <tr>
                                    <th>
                                        <label>
                                            <input type="checkbox" className="checkbox" />
                                        </label>
                                    </th>
                                    <td>
                                        <div className="flex items-center gap-3">
                                            <div className="avatar">
                                                <div className="mask mask-squircle h-12 w-12">
                                                    <img
                                                        src="https://img.daisyui.com/images/profile/demo/3@94.webp"
                                                        alt="Avatar Tailwind CSS Component" />
                                                </div>
                                            </div>
                                            <div>
                                                <div className="font-bold">Brice Swyre</div>
                                                <div className="text-sm opacity-50">China</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        Carroll Group
                                        <br />
                                        <span className="badge badge-ghost badge-sm">Tax Accountant</span>
                                    </td>
                                    <td>Red</td>
                                    <th>
                                        <button className="btn btn-ghost btn-xs">details</button>
                                    </th>
                                </tr>
                                {/* row 3 */}
                                <tr>
                                    <th>
                                        <label>
                                            <input type="checkbox" className="checkbox" />
                                        </label>
                                    </th>
                                    <td>
                                        <div className="flex items-center gap-3">
                                            <div className="avatar">
                                                <div className="mask mask-squircle h-12 w-12">
                                                    <img
                                                        src="https://img.daisyui.com/images/profile/demo/4@94.webp"
                                                        alt="Avatar Tailwind CSS Component" />
                                                </div>
                                            </div>
                                            <div>
                                                <div className="font-bold">Marjy Ferencz</div>
                                                <div className="text-sm opacity-50">Russia</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        Rowe-Schoen
                                        <br />
                                        <span className="badge badge-ghost badge-sm">Office Assistant I</span>
                                    </td>
                                    <td>Crimson</td>
                                    <th>
                                        <button className="btn btn-ghost btn-xs">details</button>
                                    </th>
                                </tr>
                                {/* row 4 */}
                                <tr>
                                    <th>
                                        <label>
                                            <input type="checkbox" className="checkbox" />
                                        </label>
                                    </th>
                                    <td>
                                        <div className="flex items-center gap-3">
                                            <div className="avatar">
                                                <div className="mask mask-squircle h-12 w-12">
                                                    <img
                                                        src="https://img.daisyui.com/images/profile/demo/5@94.webp"
                                                        alt="Avatar Tailwind CSS Component" />
                                                </div>
                                            </div>
                                            <div>
                                                <div className="font-bold">Yancy Tear</div>
                                                <div className="text-sm opacity-50">Brazil</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        Wyman-Ledner
                                        <br />
                                        <span className="badge badge-ghost badge-sm">Community Outreach Specialist</span>
                                    </td>
                                    <td>Indigo</td>
                                    <th>
                                        <button className="btn btn-ghost btn-xs">details</button>
                                    </th>
                                </tr>
                            </tbody>
                            {/* foot */}
                            <tfoot>
                                <tr>
                                    <th></th>
                                    <th>Name</th>
                                    <th>Job</th>
                                    <th>Favorite Color</th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

                <div className='w-3/12 text-end '>
                    <div className='flex '>
                        <button className='btn bg-red-500 p-5 mt-5 mr-3' onClick={red} ></button>
                        <button className='btn bg-pink-500 p-5 mt-5 mr-3' onClick={pink}></button>
                        <button className='btn bg-blue-500 p-5 mt-5 mr-3' onClick={blue}></button>
                        <button className='btn bg-yellow-400 p-5 mt-5 mr-3' onClick={yellow}></button>
                        <button className='btn bg-orange-500 p-5 mt-5 mr-3' onClick={orange}></button>
                        <div>
                            <button className='btn  mt-5 justify-end ' onClick={change}>Toggle</button>
                        </div>
                    </div>

                    <div className="stats stats-vertical shadow mt-5 justify-center">
                      <div className="stat">
                        <div className="stat-title">Downloads</div>
                        <div className={color === "red" ? "stat-value text-red-500 " :
                     color == "blue" ? "stat-value text-blue-500" : color == "pink" ? "stat-value text-pink-500 " : color == "yellow" ? "stat-value text-yellow-500" : color == "orange" ? "stat-value text-orange-500" :"stat-value"}>31K</div>
                        <div className="stat-desc">Jan 1st - Feb 1st</div>
                      </div>

                      <div className="stat">
                        <div className="stat-title">New Users</div>
                        <div className={color === "red" ? "stat-value text-red-500 " :
                     color == "blue" ? "stat-value text-blue-500" : color == "pink" ? "stat-value text-pink-500 " : color == "yellow" ? "stat-value text-yellow-500" : color == "orange" ? "stat-value text-orange-500" :"stat-value"}>4,200</div>
                        <div className="stat-desc">↗︎ 400 (22%)</div>
                      </div>

                      <div className="stat">
                        <div className="stat-title">New Registers</div>
                        <div className={color === "red" ? "stat-value text-red-500 " :
                     color == "blue" ? "stat-value text-blue-500" : color == "pink" ? "stat-value text-pink-500 " : color == "yellow" ? "stat-value text-yellow-500" : color == "orange" ? "stat-value text-orange-500" :"stat-value"}>1,200</div>
                        <div className="stat-desc">↘︎ 90 (14%)</div>
                      </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Theme